﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Script.Serialization;
using System.Collections;

namespace WebApplication1.Controllers
{

    public class Default1Controller : ApiController
    {
        // GET: api/Default1
        public IEnumerable<string> Get()
        {
            return new string[] { "value1", "value2" };
        }

        // GET: api/Default1/5
        public string Get(int id)
        {
            return "";
        }

        /// Объявление переменных
        #region
        /// словарь с данными
        Dictionary<string, string>[] MyDicts;

        /// флаг для проверки корректности данных
        bool everythingOK = true;

        /// сюда записывается дерево
        DataObject outputTree;

        /// определяющий признак
        string DetermFeature;
        #endregion

        // POST: api/Default1
        public string Post([FromBody]string data)
        {
            JavaScriptSerializer jsonchic = new JavaScriptSerializer();

            /// проверки корректности данных
            #region
            try
            {
                /// десериализация и вытаскивание данных
                #region
                Dictionary<string, object> DictObj = jsonchic.DeserializeObject(data) as Dictionary<string, object>;

                List<Dictionary<string, string>> TestDict = new List<Dictionary<string, string>>();
                foreach (object obj in (object[])DictObj["dataset"])
                {
                    Dictionary<string, string> x = new Dictionary<string, string>();
                    foreach (KeyValuePair<string, object> y in (Dictionary<string, object>)obj)
                        x[y.Key] = y.Value as string;
                    
                    TestDict.Add(x);
                }
                MyDicts = TestDict.ToArray();
                DetermFeature = DictObj["key_attribute"] as string;
                #endregion


                if (MyDicts == null || MyDicts.Length < 1 || DetermFeature == null) throw new ArgumentNullException();
                if (!MyDicts[0].ContainsKey(DetermFeature))
                    throw new ArgumentNullException();
                if (MyDicts[0].Count < 2) throw new ArgumentException();
            }
            catch (ArgumentNullException)
            {
                everythingOK = false;
            }
            catch (ArgumentException)
            {
                everythingOK = false;
            }
            catch (Exception)
            {
                everythingOK = false;
            }
            #endregion
            HttpStatusCode code = new HttpStatusCode();

            /// здесь строится дерево
            if (everythingOK)
            {
                TreeOperations.TreeMaker(ref outputTree, DetermFeature, MyDicts);
                Dictionary<string, object> finalDict = new Dictionary<string, object>();
                outputTree.isRoot = true;
                TreeOperations.TreeToDict(outputTree, finalDict);
                return jsonchic.Serialize(finalDict);
            }
            
            else return (new HttpResponseException(code)).Message;

        }
        

        // PUT: api/Default1/5
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE: api/Default1/5
        public void Delete(int id)
        {
        }
    }
}
