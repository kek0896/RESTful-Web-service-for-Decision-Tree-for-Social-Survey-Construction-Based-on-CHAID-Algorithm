﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication1
{
    public class DataObject
    {
        public bool isRoot = false;
        public DataObject child1 = null;
        public DataObject child2 = null;
        
        public double MaxXisquare { get; set; }
        public Tuple<string[], string[]> ChoosenPair { get; set; }
        public string ChoosenFeature { get; set; }
        public int GradTotal1 { get; set; }
        public int GradTotal2 { get; set; }

        public void AddChild1(DataObject Child)
        {
            child1 = Child;
        }
        public void AddChild2(DataObject Child)
        {
            child2 = Child;
        }
        
    }
}