﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication1
{
    public static class WorkingWithData
    {
        /// <summary>
        /// метод, возвращающий все возможные пары разбиений 
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="elements"></param>
        /// <returns></returns>
        public static IEnumerable<Tuple<T[], T[]>> GetTuplePartitions<T>(this T[] elements)
        {
            if (elements.Length < 2) yield break;
            for (int pattern = 0; pattern < 1 << (elements.Length - 1); pattern++)
            {
                List<T>[] resultSets = {
                    new List<T> { elements[0] }, new List<T>() };
                for (int index = 1; index < elements.Length; index++)
                {
                    resultSets[(pattern >> (index - 1)) & 1].Add(elements[index]);
                }
                if (resultSets[0].Count == 0 || resultSets[1].Count == 0)
                    continue;
                yield return Tuple.Create(resultSets[0].ToArray(), resultSets[1].ToArray());
            }
        }
        
        /// <summary>
        /// метод для получения двух массивов словарей из одного на основании данных о разбиении
        /// </summary>
        /// <param name="LeafDict"> - входной массив, который будет разбиваться </param>
        /// <param name="data"> - данные о разбиении </param>
        /// <returns></returns>
        public static List<List<Dictionary<string, string>>> GetDivision(this Dictionary<string, string>[] LeafDict, DataObject data)
        {
            if (data == null)
                return null;
            if (LeafDict.Length < 2)
                return null;

            if (data.MaxXisquare > 0)
            {
                List<List<Dictionary<string, string>>> DivisionArr = new List<List<Dictionary<string, string>>>();
                DivisionArr.Add(new List<Dictionary<string, string>>());
                DivisionArr.Add(new List<Dictionary<string, string>>());
                for (int i = 0; i < LeafDict.Length; i++)
                {
                    for (int j = 0; j < data.ChoosenPair.Item1.Length; j++)
                    {
                        if (LeafDict[i][data.ChoosenFeature] == data.ChoosenPair.Item1[j])
                        {
                            DivisionArr[0].Add(LeafDict[i]);
                            break;
                        }
                    }
                    for (int j = 0; j < data.ChoosenPair.Item2.Length; j++)
                    {
                        if (LeafDict[i][data.ChoosenFeature] == data.ChoosenPair.Item2[j])
                        {
                            DivisionArr[1].Add(LeafDict[i]);
                            break;
                        }
                    }
                }
                
                return DivisionArr;
            }
            else
                return null;
        }

        /// <summary>
        /// метод для выделения признаков
        /// </summary>
        /// <param name="LeafDict"></param>
        /// <returns></returns>
        public static List<string> GetFeatures(this List<Dictionary<string, string>> LeafDict)
        {
            List<string> features;
            if (LeafDict != null && LeafDict.Count > 0)
                features = LeafDict[0].Keys.ToList();
            else features = null;

            return features;
        }

        /// метод, в котором происходит выделелие градаций признаков и подсчёт респондентов по каждой категории
        /// полученные данные записываются в DictOfGradations 
        /// каждый словарь отвечает своему признаку и имеет вид: 
        /// [key - градация; value - общее кол-во респондентов с этой градацией]
        public static List<Dictionary<string, int>> GetGradationsAndQuantity(this List<Dictionary<string,string>> LeafDict)
        {
            int k = 0;
            List<string> features = LeafDict.GetFeatures();

            /// здесь каждый элемент массива это словарь вида [key - градация; value - общее кол-во респондентов с этой градацией]
            List<Dictionary<string, int>> DictOfGradations = new List<Dictionary<string, int>>();
            for (int j = 0; j < features.Count; j++)
            {
                DictOfGradations.Add(new Dictionary<string, int>());
            }


            while (LeafDict.Count > k)
            {
                /// для каждого признака в словаре выполняю операцию:
                for (int i = 0; i < LeafDict[k].Count; i++)
                {
                    /// словари в листе отличаются определяемыми ими признаками, 
                    /// в каждом словаре ключ - градация признака, значение - количество человек, входящих в градацию
                    /// 
                    /// если словарь с градациями не содержит такую, то добавляю новую со значением 1
                    if (!DictOfGradations[i].ContainsKey(LeafDict[k][features[i]]))
                        DictOfGradations[i].Add((LeafDict[k][features[i]]), 1);
                    /// если словарь содержит такую, то инкрементирую ее значение
                    else DictOfGradations[i][LeafDict[k][features[i]]]++;
                }
                k++;
            }
            return DictOfGradations;
        }

    }

    
}