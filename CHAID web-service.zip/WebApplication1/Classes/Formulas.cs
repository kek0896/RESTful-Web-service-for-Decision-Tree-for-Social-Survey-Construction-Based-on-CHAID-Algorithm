﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication1
{
    public static class Formulas
    {
        /// <summary>
        /// метод, который возвращает объект с информацией о разбиении
        /// </summary>
        /// <param name="determFeature"> - определяющий признак </param>
        /// <param name="MyDict"> - словарь, который нужно разбивать </param>
        /// <returns>
        /// returnObject - объект с информацией о разбиении
        /// </returns>
        public static DataObject DevideData(string determFeature, Dictionary<string,string>[] MyDict)
        {
            if (MyDict.Length < 2)
                return null;
            if (MyDict[0].Count == 1)
                return null;
            
            List<Dictionary<string, int>> DictOfGradations = MyDict.ToList().GetGradationsAndQuantity();
            List<string> features = MyDict.ToList().GetFeatures();

            /// Объявление переменных
            #region

            double finalSum = 0, xiSquareItem;

            int indexOfDeterm = features.IndexOf(determFeature);

            bool newObjectRecorded = false;
            
            /// тут будут градации рассматриваемого признака
            string[] gradationsOfAFeature;

            /// здесь хранятся градации определяемого признака
            string[] gradationsOfDeterm = DictOfGradations[indexOfDeterm].Keys.ToArray();

            /// возвращаемый объект с данными о разбиении
            DataObject returnObject = new DataObject();

            /// счетчики для подсчета количества респондентов после склеивания
            int GradTotal1count = 0;
            int GradTotal2count = 0;
            int GradTotal1 = 0;
            int GradTotal2 = 0;

            #endregion

            ///ВЫСЧИТЫВАЮ КРИТИЧЕСКОЕ ЗНАЧЕНИЕ
            double criticalValue = CriticalValue(indexOfDeterm, DictOfGradations);

            
            /// прохожу по всем признакам
            for (int i = 0; i < features.Count; i++)
            {
                if (i == indexOfDeterm)
                    continue;
                if (features.Count == 1)
                    break;

                /// Объявление переменных
                #region
                /// здесь хранятся градации рассматриваемого признака
                gradationsOfAFeature = DictOfGradations[i].Keys.ToArray();

                

                /// ПОЛУЧАЮ ВСЕ РАЗБИЕНИЯ ГРАДАЦИЙ
                var pairs = gradationsOfAFeature.GetTuplePartitions();

                /// переменные для подсчета ХИ квадрат
                double E, O = 0;
                #endregion

                /// для каждого полученного с помощью метода разбиения градаций в признаке считаю хи квадрат
                foreach (var pair in pairs)
                {
                    /// пробегаю по строчке с градациями определяющего признака
                    for (int n = 0; n < gradationsOfDeterm.Length; n++)
                    {
                        /// цикл для счета первой половины хи квадрат (для первой склееной части градаций из пары)
                        #region
                        for (int m = 0; m < pair.Item1.Length; m++)
                        {
                            /// пробегаю каждый словарь
                            for (int j = 0; j < MyDict.Length; j++)
                                if ((MyDict[j][features[i]] == pair.Item1[m]) && (MyDict[j][determFeature] == gradationsOfDeterm[n]))
                                    O++; ///идет подсчёт следующей клеточки в строчке
                                
                            GradTotal1count += DictOfGradations[i][pair.Item1[m]];
                        }
                        E = (GradTotal1count) * (DictOfGradations[indexOfDeterm][gradationsOfDeterm[n]]) / (double)(MyDict.Length);
                        xiSquareItem = (O - E) * (O - E) / E;
                        finalSum += xiSquareItem;
                        O = 0;
                        GradTotal1 = GradTotal1count;
                        GradTotal1count = 0;
                        #endregion

                        /// цикл для счета второй половины хи квадрат (для второй склееной части градаций из пары)
                        #region
                        for (int m = 0; m < pair.Item2.Length; m++)
                        {
                            for (int j = 0; j < MyDict.Length; j++)
                                if ((MyDict[j][features[i]] == pair.Item2[m]) && (MyDict[j][determFeature] == gradationsOfDeterm[n]))
                                    O++;
                                
                            GradTotal2count += DictOfGradations[i][pair.Item2[m]];
                        }

                        E = (GradTotal2count) * (DictOfGradations[indexOfDeterm][gradationsOfDeterm[n]]) / (double)(MyDict.Length);
                        xiSquareItem = (O - E) * (O - E) / E;
                        finalSum += xiSquareItem;
                        O = 0;
                        GradTotal2 = GradTotal2count;
                        GradTotal2count = 0;
                        #endregion
                    }
                    

                    /// проверка условия, в случае успеха - запись данных о разбиении в объект
                    /// запоминаю максимальное значение признака, а также разбиение по градациям, выбранный признак
                    /// и количества респондентов в каждой группе разбиения по градациям
                    #region
                    if (returnObject.MaxXisquare < finalSum && (finalSum >= criticalValue))
                    {
                        returnObject.MaxXisquare = finalSum;
                        returnObject.ChoosenPair = pair;
                        returnObject.ChoosenFeature = features[i];
                        returnObject.GradTotal1 = GradTotal1;
                        returnObject.GradTotal2 = GradTotal2;

                        newObjectRecorded = true;
                    }
                    #endregion

                    /// обнуляю счетчик для подсчета количества респондентов после склеивания градаций
                     GradTotal1 = 0;
                     GradTotal2 = 0;
                     finalSum = 0;
                }
            }

            /// здесь, если новый объект записан - метод возвращает его и удаляет из списка признаков 
            ///  и из списка массивов с градациями всё, что касается выбранного признака
            ///  если нет - возвращаю пустой объект
            #region
            if (newObjectRecorded)
            {
                foreach (Dictionary<string, string> dict in MyDict)
                    dict.Remove(returnObject.ChoosenFeature);
                return returnObject;
            }
            else return null;
            #endregion
        }

        /// <summary>
        /// метод, который вычисляет критическое значение
        /// </summary>
        /// <param name="indexOfDetermFeature"> - индекс определяющего признака </param>
        /// <param name="DictionaryOfGradations"></param>
        /// <returns>
        /// критическое значение
        /// </returns>
        public static double CriticalValue(int indexOfDetermFeature, 
            List<Dictionary<string, int>> DictionaryOfGradations)
        {

            int df = DictionaryOfGradations[indexOfDetermFeature].Count - 1;
            
            double A, B, C, D, E;

            A = 2.42851869194053;
            B = 1.29923434570151;
            C = -0.546571656167905;
            D = -0.151748822050716;
            E = 0.199961788710726;

            return df + A *(Math.Sqrt(df)) + B + C / Math.Sqrt(df) + D / df + E / (Math.Sqrt(df) * df) - 0.4; 

        }

    }
}