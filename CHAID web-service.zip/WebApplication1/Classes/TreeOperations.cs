﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication1
{
    public class TreeOperations
    {
        /// <summary>
        /// метод, который рекурсивно строит дерево
        /// </summary>
        /// <param name="tree"> - возвращаемое дерево </param>
        /// <param name="determFeature"> - ключевой признак </param>
        /// <param name="LeafDict"> - передаваемый словарь с данными о респондентах </param>
        /// <returns> tree </returns>
        public static DataObject TreeMaker(ref DataObject tree, string determFeature,
            Dictionary<string, string>[] LeafDict)
        {
            if (tree == null)
                return null;
            /// получаю словарь с градациями
            List<Dictionary<string, int>> DictOfGradations = LeafDict.ToList().GetGradationsAndQuantity();

            /// копия исходного массива (тут сохраняются признаки, которые удалятся из исходного)
            Dictionary<string, string>[] LeafDictCopy = new Dictionary<string, string>[LeafDict.Length];
            for (int i = 0; i < LeafDict.Length; i++)
            {
                LeafDictCopy[i] = new Dictionary<string, string>(LeafDict[i]);
            }

            /// если остался только один определяющий признак, возвращаю null
            if (DictOfGradations.Count == 1)
                return null;

            /// получаю данные о разбиении, записываю в текущий узел
            tree = Formulas.DevideData(determFeature, LeafDict);

            /// получаю массив из двух листьев (новых массивов словарей, полученных в ходе разбиения)
            var ArrOfNewLeaves = LeafDictCopy.GetDivision(tree);

            /// если разбиение 
            if (ArrOfNewLeaves != null)
            {
                /// создаю новые деревья для передачи в методы
                DataObject treeChild1 = null, treeChild2 = null;

                /// удаляю из словарей, содержащихся в полученных массивах, признак, по которому разбивала
                for (int i = 0; i < ArrOfNewLeaves[0].Count; i++)
                    ArrOfNewLeaves[0][i].Remove(tree.ChoosenFeature);
                for (int i = 0; i < ArrOfNewLeaves[1].Count; i++)
                    ArrOfNewLeaves[1][i].Remove(tree.ChoosenFeature);

                /// рекурсивно вызываю метод TreeMaker(), и строю дерево
                tree.AddChild1(TreeMaker(ref treeChild1, determFeature, ArrOfNewLeaves[0].ToArray()));
                tree.AddChild2(TreeMaker(ref treeChild2, determFeature, ArrOfNewLeaves[1].ToArray()));
            }

            return tree;
        }

        /// <summary>
        /// метод, который преобразует объект DataObject в массив словарей
        /// </summary>
        /// <param name="node"> - обрабатываемый узел </param>
        /// <param name="targetDict"> - словарь, куда записываются данные </param>
        public static void TreeToDict(DataObject node, Dictionary<string, object> targetDict)
        {
            /// если узел не содержит информации - это лист
            if (node == null)
                return;

            /// если узел является корнем, не записываем данных о прзнаке и значениях
            if (node.isRoot)
            {
                targetDict["feature"] = null;
                targetDict["values"] = null;
            }

            /// работа с первым ребёнком
            targetDict["child1"] = new Dictionary<string, object>();
            ((Dictionary<string, object>)targetDict["child1"])["feature"] = node.ChoosenFeature;
            ((Dictionary<string, object>)targetDict["child1"])["values"] = node.ChoosenPair.Item1;
            TreeToDict(node.child1, targetDict["child1"] as Dictionary<string, object>);

            /// работа со вторым ребёнком
            targetDict["child2"] = new Dictionary<string, object>();
            ((Dictionary<string, object>)targetDict["child2"])["feature"] = node.ChoosenFeature;
            ((Dictionary<string, object>)targetDict["child2"])["values"] = node.ChoosenPair.Item2;
            TreeToDict(node.child2, targetDict["child2"] as Dictionary<string, object>);
        }
    }
}